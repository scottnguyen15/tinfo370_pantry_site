Website must be run using a local server for now as we figure out hosting. This can be done through the LiveServer extension through Visual Studio Code.

This version is to test that the database receives the form data on submission.