import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-app.js";
import { getFirestore, collection, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDvfXs-2I3aEaO2jeCp8adyVnlOazPzyCY",
    authDomain: "pantry-a6783.firebaseapp.com",
    projectId: "pantry-a6783",
    storageBucket: "pantry-a6783.appspot.com",
    messagingSenderId: "511092628867",
    appId: "1:511092628867:web:7119204ad20d2b6bd26ab6",
    measurementId: "G-KV8KB6R6QP"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('userForm');
    if (!form) {
        console.error('Form not found on the page.');
        return;
    }

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const formData = {
            studentName: document.getElementById('stu-name').value,
            studentID: document.getElementById('stu-id').value,
            schedulePreference: document.getElementById('stu-schedule').value,
            email: document.getElementById('stu-email').value,
            ethnicity: document.querySelector('input[name="race"]:checked').value,
            genderIdentity: document.querySelector('input[name="gender"]:checked').value,
            householdSize: document.getElementById('stu-house').value,
            discoveryMethod: Array.from(document.querySelectorAll('input[name="hearing"]:checked')).map(item => item.value),
            createdAt: serverTimestamp()  // Timestamp when the document is created
        };

        try {
            const docRef = await addDoc(collection(db, "users"), formData);
            console.log('Document successfully written! ID:', docRef.id);
            alert('Form submitted successfully!');
        } catch (error) {
            console.error('Error writing document: ', error);
            alert('Error submitting form: ' + error.message);
        }
    });
});
